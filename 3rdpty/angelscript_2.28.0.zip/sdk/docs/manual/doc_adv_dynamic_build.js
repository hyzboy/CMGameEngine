var doc_adv_dynamic_build =
[
    [ "On demand builds", "doc_adv_dynamic_build_ondemand.html", null ],
    [ "Incremental builds", "doc_adv_dynamic_build_incr.html", null ],
    [ "Hot reloading scripts", "doc_adv_dynamic_build_hot.html", null ]
];