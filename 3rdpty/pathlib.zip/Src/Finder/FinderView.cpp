// FinderView.cpp : implementation of the CFinderView class
//

#include "stdafx.h"
#include "Finder.h"

#include "MainFrm.h"
#include "FinderDoc.h"
#include "FinderView.h"
#include "ddutil.h"
#include "const.h"

// minimal selection dimensions
#define MINSELSX 4
#define MINSELSY 4

static char                 szBitmap[] = "TILES";

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFinderView

IMPLEMENT_DYNCREATE(CFinderView, CCDDrawView)

BEGIN_MESSAGE_MAP(CFinderView, CCDDrawView)
//{{AFX_MSG_MAP(CFinderView)
ON_WM_ERASEBKGND()
ON_WM_SIZE()
ON_WM_LBUTTONDOWN()
ON_WM_LBUTTONUP()
ON_WM_MOUSEMOVE()
ON_WM_TIMER()
ON_WM_RBUTTONDOWN()
ON_WM_RBUTTONUP()
ON_WM_HSCROLL()
ON_WM_VSCROLL()
//}}AFX_MSG_MAP
// Standard printing commands
ON_COMMAND(ID_FILE_PRINT, CCDDrawView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_DIRECT, CCDDrawView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_PREVIEW, CCDDrawView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinderView construction/destruction

CFinderView::CFinderView()
{
    m_LButton = FALSE;
    m_RButton = FALSE;
    m_NeedRedraw = FALSE;
    m_Tile = 0;
    m_PenSizeX = 1;
    m_PenSizeY = 1;
    m_EditMode = CONTROL_MAP;
    m_LastMode = CONTROL_MAP;
    m_BkgndTile = 1;
    m_DlgBar = NULL;
    m_GridOn = TRUE;
    m_Running = FALSE;
    m_SelectionOn = FALSE;
    m_CenterTileX = 0;
    m_CenterTileY = 0;
    m_RaiseStep = 10;
    m_TimeStep = 1;
    m_Speed = 1;
    m_Priority = 1;
    m_PosX = 0;
    m_PosY = 0;
    m_TX = 0;
    m_TY = 0;
    m_Sel = 0;
}

CFinderView::~CFinderView()
{
}

BOOL CFinderView::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: Modify the Window class or styles here by modifying
    //  the CREATESTRUCT cs
    cs.style |= WS_HSCROLL|WS_VSCROLL;
    return CCDDrawView::PreCreateWindow(cs);
}

void CFinderView::PreSubclassWindow() 
{
    // TODO: Add your specialized code here and/or call the base class
    CCDDrawView::PreSubclassWindow();
}


/////////////////////////////////////////////////////////////////////////////
// CFinderView drawing

void CFinderView::OnDraw(CDC* pDC)
{
    DDBLTFX ps;
    CRect source;
    CRect dest;
    
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    GetClientRect(&dest); source = dest;  
    
    // Clear surface
    ps.dwSize = sizeof(ps);
    ps.dwFillColor = DDRGB(255,255,255);
    if (lpDDSOne->Blt(&dest, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    
    if (!pDoc->DocReady) return;
    
    int pom;
    
    int ShiftX = m_PosX;
    int ShiftY = m_PosY;
    int px = ShiftX/TILE_X;
    int py = ShiftY/TILE_Y;
    
    if (px<0) px=0;
    if (py<0) py=0;
    
    int qx = px + source.Width()/TILE_X + 2;
    int qy = py + source.Height()/TILE_Y + 2;
    
    if (qx >= pDoc->Engine->MapSX) qx=pDoc->Engine->MapSX-1;
    if (qy >= pDoc->Engine->MapSY) qy=pDoc->Engine->MapSY-1;
    
    // tiles
    int tx = TILE_X;
    int ty = TILE_Y;
    
    int ttsx = px*tx-ShiftX;
    int ttsy = py*ty-ShiftY;
    int ttex = qx*tx-ShiftX;
    int ttey = qy*ty-ShiftY;
    
    CRect rr;   // 
    CRect ir;   // intersection rectangle
    CPoint sp;   // source graphics
    CRect sr;   // source rectangle
    POINT p;
    int j,i;
    
    // tiles
    int tsx=px;
    int tsy=py;
    for (j=ttsy; j<=ttey; j+=ty,tsy++)
    {
        tsx = px;
        for (i=ttsx; i<=ttex; i+=tx,tsx++)
        {
            MapNode* node = peMapXY(pDoc->Engine,tsx,tsy);
            
            pom = node->TC;
            if (pom==pDoc->Engine->MAXTC)
                ps.dwFillColor = DDRGB(0,0,0);
            else
                ps.dwFillColor = DDRGB(255-pom,255-pom,255-pom);
            
            rr.SetRect(i,j, i+tx, j+ty);
            ir.IntersectRect(&rr,&dest);
            if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
            
            
            if (node->FootSteps)
            {
                sp.x=2*tx;  
                sp.y=0;  
                rr.SetRect(i, j, i+tx, j+ty);
                ir.IntersectRect(&rr,&dest);
                sr.SetRect(ir.left-rr.left+sp.x,    ir.top-rr.top+sp.y, 
                    ir.right-rr.right+sp.x+tx, ir.bottom-rr.bottom+sp.y+ty);
                if (lpDDSOne->Blt(&ir, lpDDSG, &sr, DDBLT_KEYSRC , NULL)==DDERR_SURFACELOST) RestoreSurfaces();
            }
        }
    }
    
    
    ttex+=tx;
    ttey+=ty;
    
    // grid
    if (m_GridOn)
    {
        ps.dwFillColor = GRID_COLOR;
        for (j=ttsy; j<=ttey; j+=ty) 
        {  
            // Horizontal line
            rr.SetRect(ttsx,j,ttex,j+1);
            ir.IntersectRect(&rr,&dest);
            if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
        }
        for (j=ttsx; j<=ttex; j+=tx)
        {  
            // Vertical line
            rr.SetRect(j,ttsy,j+1,ttey);
            ir.IntersectRect(&rr,&dest);
            if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
        }
    }
	
    CRect VisibleMap(px, py, qx+1, qy+1
		);
    PED* PE = pDoc->Engine;
    
    // draw arrows
    Walker* w; 
    w = pDoc->Engine->FirstWalker;
    while (w)
    {
        if (!(w->State&PEW_STANDING))
        { 
            PathStep* ps1;
            PathStep* ps2;
            i = w->Step+1;
            do 
            {
                ps1 = &w->Path[i-1];
                ps2 = &w->Path[i];
                i++;

                if (ps2->Type&PST_END)
                {
                    if ((ps2->Pos.X!=w->Dest.X) &&
                        (ps2->Pos.Y!=w->Dest.Y))  // walker didn't reach dest position
                        sp.x=3*tx; // draw ?
                    else
                        sp.x=4*tx; // draw X
                    
                    sp.y=0;  
                }
                else // Draw arrow
                {
                    sp.x=Delta2Dir[ps2->Pos.Y-ps1->Pos.Y+1][ps2->Pos.X-ps1->Pos.X+1]*tx;  
                    sp.y=ty;  
                }
                p.x = ps2->Pos.X;
                p.y = ps2->Pos.Y;
                if (VisibleMap.PtInRect(p))  // is step visible ?
                {
                    int zx = p.x*tx-ShiftX;
                    int zy = p.y*ty-ShiftY;
                    rr.SetRect(zx, zy, zx+tx, zy+ty);
                    ir.IntersectRect(&rr,&dest);
                    sr.SetRect(ir.left-rr.left+sp.x,    ir.top-rr.top+sp.y, 
                    ir.right-rr.right+sp.x+tx, ir.bottom-rr.bottom+sp.y+ty);
                    if (lpDDSOne->Blt(&ir, lpDDSG, &sr, DDBLT_KEYSRC , NULL)==DDERR_SURFACELOST) RestoreSurfaces();
                }
                
            } while (!(ps2->Type&PST_END));
            
        } 
        w = w->Next;
    }
    
    // draw walkers  
    w = pDoc->Engine->FirstWalker;
	while (w)
	{
		if (w->State&PEW_DEADLOCK)
    {
			sp.x=5*tx;  // frozen/deadlocked walker in source bitmap
			sp.y=0;  
    }
    else
		  if (w->State&PEW_BLOCKED)
      {
			  sp.x=6*tx;  // blocked walker in source bitmap
			  sp.y=0;  
      }
      else
        if (w->State&PEW_SELECTED)
		    { 
			    sp.x=tx;  // selected walker in source bitmap
			    sp.y=0;  
		    } 
		    else
		    {
			    sp.x=0;  // unselected walker in source bitmap
			    sp.y=0;  
		    } 
		
		p.x = w->Pos.X;
		p.y = w->Pos.Y;
		if (VisibleMap.PtInRect(p))  // is walker visible ?
		{
			// Draw walker
			int zx = p.x*tx-ShiftX;
			int zy = p.y*ty-ShiftY;
			rr.SetRect(zx, zy, zx+tx, zy+ty);
			ir.IntersectRect(&rr,&dest);
			sr.SetRect(ir.left-rr.left+sp.x,    ir.top-rr.top+sp.y, 
				ir.right-rr.right+sp.x+tx, ir.bottom-rr.bottom+sp.y+ty);
			if (lpDDSOne->Blt(&ir, lpDDSG, &sr, DDBLT_KEYSRC , NULL)==DDERR_SURFACELOST) RestoreSurfaces();
		}
        w = w->Next;
    }    
    // Put bitmap - test
    //  CRect rcRect(0,0,128,32);
    //  lpDDSOne->BltFast(0, 0, lpDDSG, &rcRect, DDBLTFAST_NOCOLORKEY);
    
    // draw board border 
    ps.dwFillColor = BORDER_COLOR;
    int msx = pDoc->Engine->MapSX * TILE_X;
    int msy = pDoc->Engine->MapSY * TILE_Y;
    rr.SetRect(-m_PosX, -m_PosY, -m_PosX+1, msy-m_PosY);
    ir.IntersectRect(&rr,&dest);
    if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    rr.SetRect(msx-m_PosX, -m_PosY, msx-m_PosX+1, msy-m_PosY);
    ir.IntersectRect(&rr,&dest);
    if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    rr.SetRect(-m_PosX, -m_PosY, msx-m_PosX, -m_PosY+1);
    ir.IntersectRect(&rr,&dest);
    if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    rr.SetRect(-m_PosX, msy-m_PosY, msx-m_PosX, msy-m_PosY+1);
    ir.IntersectRect(&rr,&dest);
    if (lpDDSOne->Blt(&ir, NULL, NULL, DDBLT_COLORFILL , &ps)==DDERR_SURFACELOST) RestoreSurfaces();
	
    // draw selection rectangle
    if (m_SelectionOn) DrawSelectionDD(&m_Selection);
	
    // Blit to the display
    Offset2Screen(&source, &dest);
}

/////////////////////////////////////////////////////////////////////////////
// CFinderView printing

BOOL CFinderView::OnPreparePrinting(CPrintInfo* pInfo)
{
    // default preparation
    return DoPreparePrinting(pInfo);
}

void CFinderView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
    // TODO: add extra initialization before printing
}

void CFinderView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
    // TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CFinderView diagnostics

#ifdef _DEBUG
void CFinderView::AssertValid() const
{
    CCDDrawView::AssertValid();
}

void CFinderView::Dump(CDumpContext& dc) const
{
    CCDDrawView::Dump(dc);
}

CFinderDoc* CFinderView::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFinderDoc)));
    return (CFinderDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFinderView message handlers

BOOL CFinderView::OnEraseBkgnd(CDC* pDC) 
{
    return FALSE;
}

BOOL CFinderView::InitGraphics()
{
    // Create and set the palette
    lpDDPal = DDLoadPalette(lpDD, szBitmap);
    if (lpDDPal)
        lpDDSPrimary->SetPalette(lpDDPal);
    
    // Create the offscreen surface, by loading our bitmap.
    lpDDSG = DDLoadBitmap(lpDD, szBitmap, 0, 0);
    if (lpDDSG == NULL)
        return FALSE;
    
    // Set the color key for this bitmap (black)
    DDSetColorKey(lpDDSG, CLR_INVALID); // keycolor is upper left corner pixel of bitmap
    
    return TRUE;
}

void CFinderView::OnInitialUpdate() 
{
    // Set refresh timer
    SetTimer( TID_REFRESH, 100, NULL);
    
    CCDDrawView::OnInitialUpdate();
    CFinderDoc* pDoc = GetDocument();
    ASSERT(pDoc != NULL);
    
    InitGraphics();
    
    
    CRect rect;
    GetClientRect(&rect);
    RecalculateScrolling(&rect, TRUE);
    
    UpdateEnginePanel();
    UpdateWalkerPanel();
}

void CFinderView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
    // We can't interpret the hint, so assume that anything might
    // have been updated.
    Invalidate(TRUE);
    return;
}

/////////////////////////////////////////////////////////////////////////////
// CView scrolling

void CFinderView::OnHScroll(UINT nSBCode, UINT nm_Pos, CScrollBar* pScrollBar)
{
    if (pScrollBar != NULL && pScrollBar->SendChildNotifyLastMsg())
        return;     // eat it
    
    // ignore scroll bar msgs from other controls
    if (pScrollBar != GetScrollBarCtrl(SB_HORZ))
        return;
    
    OnScroll(MAKEWORD(nSBCode, -1), nm_Pos);
    
    //CCDDrawView::OnHScroll(nSBCode, nm_Pos, pScrollBar);
}

void CFinderView::OnVScroll(UINT nSBCode, UINT nm_Pos, CScrollBar* pScrollBar)
{
    if (pScrollBar != NULL && pScrollBar->SendChildNotifyLastMsg())
        return;     // eat it
    
    // ignore scroll bar msgs from other controls
    if (pScrollBar != GetScrollBarCtrl(SB_VERT))
        return;
    
    OnScroll(MAKEWORD(-1, nSBCode), nm_Pos);
    
    //CCDDrawView::OnVScroll(nSBCode, nm_Pos, pScrollBar);
}


BOOL CFinderView::OnScroll(UINT nScrollCode, UINT nm_Pos, BOOL bDoScroll)
{
    // calc new x m_Position
    int x = GetScrollPos(SB_HORZ);
    int xOrig = x;
    
    switch (LOBYTE(nScrollCode))
    {
    case SB_TOP:
        x = 0;
        break;
    case SB_BOTTOM:
        x = INT_MAX;
        break;
    case SB_LINEUP:
        x -= m_sizeLine.cx;
        break;
    case SB_LINEDOWN:
        x += m_sizeLine.cx;
        break;
    case SB_PAGEUP:
        x -= m_sizePage.cx;
        break;
    case SB_PAGEDOWN:
        x += m_sizePage.cx;
        break;
    case SB_THUMBTRACK:
        x = nm_Pos;
        break;
    }
    
    // calc new y m_Position
    int y = GetScrollPos(SB_VERT);
    int yOrig = y;
    
    switch (HIBYTE(nScrollCode))
    {
    case SB_TOP:
        y = 0;
        break;
    case SB_BOTTOM:
        y = INT_MAX;
        break;
    case SB_LINEUP:
        y -= m_sizeLine.cy;
        break;
    case SB_LINEDOWN:
        y += m_sizeLine.cy;
        break;
    case SB_PAGEUP:
        y -= m_sizePage.cy;
        break;
    case SB_PAGEDOWN:
        y += m_sizePage.cy;
        break;
    case SB_THUMBTRACK:
        y = nm_Pos;
        break;
    }
    
    BOOL bResult = OnScrollBy(CSize(x - xOrig, y - yOrig), bDoScroll);
    if (bResult && bDoScroll)
        m_NeedRedraw = TRUE;
    
    //  return bResult;
    return true;//CCDDrawView::OnScroll(nScrollCode, nm_Pos, bDoScroll);
}


BOOL CFinderView::OnScrollBy(CSize sizeScroll, BOOL bDoScroll)
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    int xOrig, x;
    int yOrig, y;
    
    // don't scroll if there is no valid scroll range (ie. no scroll bar)
    CScrollBar* pBar;
    DWORD dwStyle = GetStyle();
    pBar = GetScrollBarCtrl(SB_VERT);
    if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
        (pBar == NULL && !(dwStyle & WS_VSCROLL)))
    {
        // vertical scroll bar not enabled
        sizeScroll.cy = 0;
    }
    pBar = GetScrollBarCtrl(SB_HORZ);
    if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
        (pBar == NULL && !(dwStyle & WS_HSCROLL)))
    {
        // horizontal scroll bar not enabled
        sizeScroll.cx = 0;
    }
    
    // adjust current x m_Position
    xOrig = x = GetScrollPos(SB_HORZ);
    int xMax = GetScrollLimit(SB_HORZ);
    x += sizeScroll.cx;
    if (x < 0)
        x = 0;
    else if (x > xMax)
        x = xMax;
    
    // adjust current y m_Position
    yOrig = y = GetScrollPos(SB_VERT);
    int yMax = GetScrollLimit(SB_VERT);
    y += sizeScroll.cy;
    if (y < 0)
        y = 0;
    else if (y > yMax)
        y = yMax;
    
    // did anything change?
    if (x == xOrig && y == yOrig)
        return FALSE;
    
    if (bDoScroll)
    {
        // do scroll and update scroll m_Positions
        //		ScrollWindow(-(x-xOrig), -(y-yOrig));
        if (x != xOrig)
            SetScrollPos(SB_HORZ, x);
        if (y != yOrig)
            SetScrollPos(SB_VERT, y);
        if (x!=xOrig) m_PosX = x;
        if (y!=yOrig) m_PosY = y;
    }
    return TRUE;
}

BOOL CFinderView::RecalculateScrolling(CRect* rect, BOOL ResetPos)
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    static int lastsx = 0;
    static int lastsy = 0;
	
    if (!pDoc->IsReady()) return FALSE;
    CSize ds = pDoc->GetDocSize();
    m_sizeDoc       = ds;
    m_sizeLine.cx   = TILE_X;
    m_sizeLine.cy   = TILE_Y;
    m_sizePage.cx   = rect->Width();
    m_sizePage.cy   = rect->Height();
	
	//    ds.cx-=m_sizeLine.cx;
	//    ds.cy-=m_sizeLine.cy;
	
    ds.cx-=m_sizePage.cx;
    ds.cy-=m_sizePage.cy;
	
	ResetPos = 1;
    if (ResetPos)
    {
        if (ds.cx<0)
        {
			m_PosX = ds.cx / 2;
			lastsx = -m_PosX;
        }
        else
			m_PosX = 0;
		
		
        if (ds.cy<0)
        {
            m_PosY = ds.cy / 2;
            lastsy = -m_PosY;
        }
        else
			m_PosY = 0;
    }
    else
    {
        if (ds.cx<0) 
        {
            m_PosX = ds.cx / 2;
            lastsx = -m_PosX;
        }
        else
        {
            if (lastsx) 
            {
                m_PosX+=lastsx;
                lastsx = 0;
            }
            if (m_PosX + m_sizePage.cx > m_sizeDoc.cx) m_PosX = m_sizeDoc.cx - m_sizePage.cx;
        }
        
        if (ds.cy<0) 
        {
            m_PosY = ds.cy / 2;
            lastsy = -m_PosY;
        }
        else
        {
            if (lastsy) 
            {
                m_PosY+=lastsy;
                lastsy = 0;
            }
            if (m_PosY + m_sizePage.cy > m_sizeDoc.cy) m_PosY = m_sizeDoc.cy - m_sizePage.cy;
        }
    }
    
    
    
    SCROLLINFO si;
    
    GetScrollInfo(SB_HORZ, &si);
    si.cbSize = sizeof(si);
    si.fMask = SIF_DISABLENOSCROLL|SIF_PAGE|SIF_RANGE;
    si.nMin = 0;
    si.nMax = m_sizeDoc.cx;
    si.nPage = m_sizePage.cx;
    if (si.nMax<si.nPos) si.nPos = si.nMax;
    SetScrollInfo(SB_HORZ, &si);
    
    GetScrollInfo(SB_VERT, &si);
    si.cbSize = sizeof(si);
    si.fMask = SIF_DISABLENOSCROLL|SIF_PAGE|SIF_RANGE;
    si.nMin = 0;
    si.nMax = m_sizeDoc.cy;
    si.nPage = m_sizePage.cy;
    if (si.nMax<si.nPos) si.nPos = si.nMax;
    SetScrollInfo(SB_VERT, &si);
    
    SetScrollPos(SB_HORZ, max(m_PosX,0));
    SetScrollPos(SB_VERT, max(m_PosY,0));
    
    OnScrollBy(CSize(0,0), TRUE);  
    return TRUE;
}

void CFinderView::OnSize(UINT nType, int cx, int cy) 
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
	
    CCDDrawView::OnSize(nType, cx, cy);
    RecalculateScrolling(&CRect(0,0,cx,cy));
	if (pDoc->Engine) UpdateEnginePanel();
}

void CFinderView::OnLButtonDown(UINT nFlags, CPoint point) 
{
    m_LButton = TRUE;
    if (GetCapture()!=this) SetCapture();
	
    SetCapture();
    m_ClickPoint = point;
    m_Selection.SetRect(point.x, point.y, point.x, point.y);
    m_CenterTileX=-1;
    m_CenterTileY=-1;
    CCDDrawView::OnLButtonDown(nFlags, point);
    OnMouseMove(nFlags, point);
}

void CFinderView::OnRButtonDown(UINT nFlags, CPoint point) 
{
    m_RButton = TRUE;
    if (GetCapture()!=this) SetCapture();
	
    CCDDrawView::OnRButtonDown(nFlags, point);
}

void CFinderView::OnLButtonUp(UINT nFlags, CPoint point) 
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    m_LButton = FALSE;
    int RX,RY,QX,QY;
    int i,j;
    MapNode* node = NULL;
    Walker* w;
    
    switch (m_EditMode)
    {
    case EDIT_ADDWALKER:
        // add walker
        Point2Tile(point.x, point.y, &RX, &RY);
        node = peMapXY(pDoc->Engine, RX, RY);
        if (node)
            if ((node->Owner==-1) && (node->TC!=pDoc->Engine->MAXTC)) // is tile free
            {
                w = peAddWalker(pDoc->Engine);
                if (!w) 
                { 
                    MessageBox("Unable to create new walker."); 
                    break;
                }
                InitWalkerSettings(w);
                peSetPosWalker(pDoc->Engine, w, peMapXY(pDoc->Engine, RX, RY));
                
                m_NeedRedraw = TRUE;
            }
            break;
            
    case CONTROL_MAP:
        if ((m_Selection.left == m_Selection.right) && (m_Selection.top == m_Selection.bottom)) // one point click
        {
            Point2Tile(m_ClickPoint.x, m_ClickPoint.y, &RX, &RY);
            node = peMapXY(pDoc->Engine, RX, RY);
            if (node)
            {
                if (node->Owner!=-1)
                {  
                    if (!(nFlags&MK_CONTROL))
                        peUnselectAllWalkers(pDoc->Engine); // unselect all walkers
                    
                    pDoc->Engine->Walkers[node->Owner].State|=PEW_SELECTED;
                    m_NeedRedraw = TRUE;
                }
                else 
                {
                    // all selected walkers go to click point
                    w = pDoc->Engine->FirstWalker;
                    while (w)
                    {
                        if (w->State&PEW_SELECTED)
                        {
                            pePlanWalker(pDoc->Engine, w, node, PRT_STD);
                        }
                        w = w->Next;
                    }
                    m_NeedRedraw=TRUE;
                }
            }
        }
        else // rectangular selection
        {
            // check if the rectangle is at least MINSELSXxMINSELSY pixels
            if (abs(m_Selection.right - m_Selection.left)>=MINSELSX &&
                abs(m_Selection.bottom - m_Selection.top)>=MINSELSY)
            {
                
                if (!(nFlags&MK_CONTROL))
                    peUnselectAllWalkers(pDoc->Engine); // unselect all walkers
                
                // get selected rectangle in map units (RX,RY QX,QY)
                RX = (m_PosX + m_Selection.left) / TILE_X;
                RY = (m_PosY + m_Selection.top) / TILE_Y;
                QX = (m_PosX + m_Selection.right) / TILE_X;
                QY = (m_PosY + m_Selection.bottom) / TILE_Y;
                
                // select all walkers in rectangle
                for (j=RY; j<=QY; j++) {
                    for (i=RX; i<=QX; i++) {  
                        node = peMapXY(pDoc->Engine, i, j);
                        if (node && node->Owner!=-1) pDoc->Engine->Walkers[node->Owner].State|=PEW_SELECTED;   // select walker
                    }
                    
                }
            }
            m_SelectionOn = FALSE;
            ClearSelection(&m_Selection);
            m_NeedRedraw = TRUE;
        }
        break;
    } 
    
    if (!m_LButton && !m_RButton) ReleaseCapture();
    CCDDrawView::OnLButtonUp(nFlags, point);
}

void CFinderView::OnRButtonUp(UINT nFlags, CPoint point) 
{
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    m_RButton = FALSE;
    switch (m_EditMode) {
    case EDIT_ADDWALKER:
        m_EditMode = m_LastMode;
        frame->DisableAdd();
        frame->Mcheck();
        break;
        
    case CONTROL_MAP:
        PED* PE = pDoc->Engine;
        ASSERT(PE);
        // unselect all walkers
        peUnselectAllWalkers(PE);
        m_NeedRedraw = TRUE;
        break;
    }
    
    if (!m_LButton && !m_RButton) ReleaseCapture();
    CCDDrawView::OnRButtonUp(nFlags, point);
}


void CFinderView::OnMouseMove(UINT nFlags, CPoint point) 
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    CRect ClientRect;
    GetClientRect(&ClientRect);
    MapNode* node = NULL;
    
    int ax,ay, bx,by;
    int RX;
    int RY;
    int i,j;
    CRect psr;
    Point2Tile(point.x, point.y, &RX, &RY);
    m_TX = RX;
    m_TY = RY;
    
    if (m_EditMode!=CONTROL_MAP && m_EditMode!=EDIT_ADDWALKER)  // jsem v nejakem editacnim modu
    {
        if ((point.x<0) || (point.x>ClientRect.right) ||
            (point.y<0) || (point.y>ClientRect.bottom)) 
        {        
            ClearSelection(&m_Selection);
            m_SelectionOn = FALSE;
            ReleaseCapture(); 
            return;
        }
        
        if (!((m_CenterTileX==RX) && (m_CenterTileY==RY)))
        { 
            m_CenterTileX=RX;
            m_CenterTileY=RY;
            CenterTile2PenSquare(RX, RY, psr);
            Tile2Point(psr.left, psr.top, 0, &ax, &ay);
            Tile2Point(psr.right, psr.bottom, 2, &bx, &by);
            UpdateSelection(&CRect(ax+1, ay+1, bx+1, by+1));
            m_SelectionOn = TRUE;
        }
    }
    
    
    switch (m_EditMode)
    {
    case EDIT_MAP:
        if (m_LButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node && node->TC!=m_Tile)
                    {
                        node->TC=m_Tile;
                    }
                }
                m_NeedRedraw=TRUE;
        }
        if (m_RButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node && node->TC!=m_BkgndTile)
                    {
                        node->TC=m_BkgndTile;
                    }
                }
                m_NeedRedraw=TRUE;
        }
        break;
        
    case RAISE_MAP:
        if (m_LButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node)
                        RaiseTile(node);
                }
                m_NeedRedraw=TRUE;
        }
        if (m_RButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node)
                        LowerTile(node);
                }
                m_NeedRedraw=TRUE;
        }
        break;
        
    case LOWER_MAP:
        if (m_LButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node)
                        LowerTile(node);
                }
                m_NeedRedraw=TRUE;
        }
        if (m_RButton)
        { 
            CenterTile2PenSquare(RX, RY, psr);
            for (j=psr.top; j<=psr.bottom; j++)
                for (i=psr.left; i<=psr.right; i++)
                {
                    node = peMapXY(pDoc->Engine, i, j);
                    if (node)
                        RaiseTile(node);
                }
                m_NeedRedraw=TRUE;
        }
        break;
        
        
    case CONTROL_MAP:
        if (m_LButton)
        {
            UpdateSelection(&CRect(m_ClickPoint.x, m_ClickPoint.y, point.x, point.y));
            m_SelectionOn = TRUE;
        }
        break;
    }
    CCDDrawView::OnMouseMove(nFlags, point);
}

void CFinderView::OnTimer(UINT nIDEvent) 
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    if (m_NeedRedraw) 
    {
        RedrawWindow();
        UpdateEnginePanel();
        UpdateWalkerPanel();
        m_NeedRedraw = FALSE;
    }
    
    if (m_Running)
    {
        peTimeForward(pDoc->Engine, m_TimeStep);
        m_NeedRedraw = TRUE;
    }
    
    CCDDrawView::OnTimer(nIDEvent);
}

void CFinderView::UpdateEnginePanel()
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    CString s;
    CDialogBar *Dlg = frame->GetDlgBar();
    ASSERT_VALID(Dlg);
    CWnd* wnd;
    PED *PE = pDoc->Engine;
    ASSERT(PE);
    Walker *w;
    Request *r;
    int c;
    
    s.Format("Time = %d", PE->Time);
    wnd = Dlg->GetDlgItem(IDC_PTIME);
    if (wnd) wnd->SetWindowText(s);
    
    s.Format("SID = %d", PE->LastSID);
    wnd = Dlg->GetDlgItem(IDC_PSID);
    if (wnd) wnd->SetWindowText(s);
    
    c = 0;
    w = PE->FirstWalker;
    while (w)
    {
        if (w->Path) c++;
        w = w->Next;
    }
    s.Format("Paths = %d", c);
    wnd = Dlg->GetDlgItem(IDC_PPATHS);
    if (wnd) wnd->SetWindowText(s);
    
    s.Format("Nodes = %d", peENodes);
    wnd = Dlg->GetDlgItem(IDC_PENODES);
    if (wnd) wnd->SetWindowText(s);
    
    c = 0;
    r = PE->FirstRequest;
    while (r!=PE->LastRequest)
    {
        c++;
        if (r==PE->RequestsTop) r=PE->RequestsBottom; else r++; 
    }
    s.Format("Requests = %d", c);
    wnd = Dlg->GetDlgItem(IDC_PREQ);
    if (wnd) wnd->SetWindowText(s);
	
    c = 0;
    
    int d = 0;
	w = PE->FirstWalker;
	while (w)
	{
		c++;
        if (w->State&PEW_SELECTED) d++;
		w = w->Next;
	}
    m_Sel = d;
    s.Format("Walkers = %d", c);
    wnd = Dlg->GetDlgItem(IDC_PWAL);
    if (wnd) wnd->SetWindowText(s);
	
}

void CFinderView::UpdateWalkerPanel()
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    CString s;
    CDialogBar *Dlg = frame->GetDlgBar();
    ASSERT_VALID(Dlg);
    CWnd* wnd;
    PED *PE = pDoc->Engine;
    ASSERT(PE);
    Walker *w, *sv;
    int c;
    
    c = 0;
    w = PE->FirstWalker;
    while (w)
    {
        if (w->State&PEW_SELECTED) 
        {
            sv = w;
            c++;
        }
        w = w->Next;
    }
    
    if (c==1)
    {
        s.Format("State = %d\nPX=%d, PY=%d\nS=%d, L=%d", 
            sv->State, sv->Pos.X, sv->Pos.Y,sv->Step, sv->Length);
        wnd = Dlg->GetDlgItem(IDC_WTEXT);
        if (wnd) wnd->SetWindowText(s);
        
        Dlg->SetDlgItemInt(IDC_WSPEED, sv->Speed);
        Dlg->SetDlgItemInt(IDC_WPRIORITY, sv->Priority);
    }
    else
    {
        wnd = Dlg->GetDlgItem(IDC_WTEXT);
        if (wnd) wnd->SetWindowText("");
    }
}


void CFinderView::UpdateSelection(CRect* r)
{
    // update selection rectangle
    ClearSelectionDD(&m_Selection);
    CopySelection(&m_Selection);
    DrawSelection(r);
}

void CFinderView::ClearSelection(CRect* r)
{
    ClearSelectionDD(r);
    CopySelection(r);
}

void CFinderView::DrawSelection(CRect* r)
{
    // draw selection rectangle
    CRect ClientRect;
    GetClientRect(&ClientRect);
    
    ClientRect.right-=1;
    ClientRect.bottom-=1;
    ClientRect.left+=1;
    ClientRect.top+=1;
    r->NormalizeRect();
    m_Selection.IntersectRect(r, &ClientRect);
    DrawSelectionDD(&m_Selection);
    CopySelection(&m_Selection);
}

void CFinderView::CopySelection(CRect* r)
// copies Selection rectangle given in r with bitmap from DDSOne backbuffer
{
    CRect dr, s;
    CPoint pt(0,0);
    ClientToScreen(&pt);
    
    // copy four lines of rectangle
    s.SetRect(r->left, r->top, r->right, r->top+1);
    dr = s; dr.OffsetRect(pt.x, pt.y);
    if (lpDDSPrimary->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->top, r->left+1, r->bottom);
    dr = s; dr.OffsetRect(pt.x, pt.y);
    if (lpDDSPrimary->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->right, r->top, r->right+1, r->bottom);
    dr = s; dr.OffsetRect(pt.x, pt.y);
    if (lpDDSPrimary->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->bottom, r->right+1, r->bottom+1);
    dr = s; dr.OffsetRect(pt.x, pt.y);
    if (lpDDSPrimary->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
}

void CFinderView::DrawSelectionGDI(CRect* r)
// uses GDI to draw Selection rectangle
{
    CDC* dc = GetDC();
    CPoint rectangle[5];
    rectangle[0].x=r->left;
    rectangle[0].y=r->top;
    rectangle[1].x=r->right;
    rectangle[1].y=r->top;
    rectangle[2].x=r->right;
    rectangle[2].y=r->bottom;
    rectangle[3].x=r->left;
    rectangle[3].y=r->bottom;
    rectangle[4].x=r->left;
    rectangle[4].y=r->top;
    
    CPen* oldpen;
    CPen pen(PS_SOLID, 1, RGB(0xFF,0x00,0x00));
    oldpen = dc->SelectObject(&pen);
    dc->Polyline(rectangle, 5);
    dc->SelectObject(oldpen);
}

void CFinderView::DrawSelectionDD(CRect* r)
// uses DD to draw Selection rectangle to DDSOne back buffer + saves background
{
    CRect dr, s;
    CPoint pt(0,0);
    DDBLTFX ps;
    
    r->NormalizeRect();
    
    ps.dwSize = sizeof(ps);
    ps.dwFillColor = RECTANGLE_COLOR;
    
    //	ClientToScreen(&pt);
    
    // draw four lines of rectangle
    s.SetRect(r->left+1, r->top, r->right, r->top+1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.top=0; dr.bottom=1;
    if (lpDDSHL->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    // draw line
    if (lpDDSOne->Blt(&s, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->top, r->left+1, r->bottom-1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.left=0; dr.right=1;
    if (lpDDSVL->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    // draw line
    if (lpDDSOne->Blt(&s, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->right, r->top+1, r->right+1, r->bottom);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.left=1; dr.right=2;
    if (lpDDSVL->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    // draw line
    if (lpDDSOne->Blt(&s, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->bottom, r->right-1, r->bottom+1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.top=1; dr.bottom=2;
    if (lpDDSHL->Blt(&dr, lpDDSOne, &s, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    // draw line
    if (lpDDSOne->Blt(&s, NULL, NULL, DDBLT_COLORFILL, &ps)==DDERR_SURFACELOST) RestoreSurfaces();
}

void CFinderView::ClearSelectionDD(CRect* r)
// clears rectangle in DDSOne
{
    CRect dr, s;
    CPoint pt(0,0);
    
    r->NormalizeRect();
    
    // draw four lines of rectangle
    s.SetRect(r->left+1, r->top, r->right, r->top+1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.top=0; dr.bottom=1;
    if (lpDDSOne->Blt(&s, lpDDSHL, &dr, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->top, r->left+1, r->bottom-1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.left=0; dr.right=1;
    if (lpDDSOne->Blt(&s, lpDDSVL, &dr, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->right, r->top+1, r->right+1, r->bottom);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.left=1; dr.right=2;
    if (lpDDSOne->Blt(&s, lpDDSVL, &dr, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
    
    s.SetRect(r->left, r->bottom, r->right-1, r->bottom+1);
    s.OffsetRect(pt.x, pt.y);
    dr = s; dr.top=1; dr.bottom=2;
    if (lpDDSOne->Blt(&s, lpDDSHL, &dr, 0, NULL)==DDERR_SURFACELOST) RestoreSurfaces();
}


BOOL CFinderView::InitWalkerSettings(Walker* w)
{
    w->State = PEW_USED;
    w->Path = NULL;
    w->Step = NULL;
    
    w->Speed = m_Speed;
    w->Priority = m_Priority;
    
    return TRUE;
}

void CFinderView::Point2Tile(int px, int py, int *tx, int *ty)
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    (*tx) = (m_PosX + px) / TILE_X;
    (*ty) = (m_PosY + py) / TILE_Y;
    if ((*tx)<0) (*tx)=0;
    if ((*ty)<0) (*ty)=0;
    if ((*tx)>=pDoc->Engine->MapSX) (*tx)=pDoc->Engine->MapSX-1;
    if ((*ty)>=pDoc->Engine->MapSY) (*tx)=pDoc->Engine->MapSY-1;
    
}

void CFinderView::Tile2Point(int tx, int ty, char type, int *px, int *py)
{
    switch (type) {
    case 0:
        (*px)=tx*TILE_X - m_PosX;
        (*py)=ty*TILE_Y - m_PosY;
        break;
    case 1:
        (*px)=(tx+1)*TILE_X - m_PosX;
        (*py)=ty*TILE_Y - m_PosY;
        break;
    case 2:
        (*px)=(tx+1)*TILE_X - m_PosX;
        (*py)=(ty+1)*TILE_Y - m_PosY;
        break;
    case 3:
        (*px)=tx*TILE_X - m_PosX;
        (*py)=(ty+1)*TILE_Y - m_PosY;
        break;
    }
}

void CFinderView::CenterTile2PenSquare(int tx, int ty, CRect &c)
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    c.left = tx - m_PenSizeX/2;
    c.right = c.left + m_PenSizeX -1;
    c.top = ty - m_PenSizeY/2;
    c.bottom = c.top + m_PenSizeY -1;
    
    if (c.left<0) c.left=0;
    if (c.top<0) c.top=0;
    if (c.right>=pDoc->Engine->MapSX) c.right=pDoc->Engine->MapSX-1;
    if (c.bottom>=pDoc->Engine->MapSY) c.bottom=pDoc->Engine->MapSY-1;
}

void CFinderView::RaiseTile(MapNode* node)
{
    CFinderDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    
    node->TC+=m_RaiseStep;
    if (node->TC>=0xFF) node->TC=pDoc->Engine->MAXTC;
}

void CFinderView::LowerTile(MapNode* node)
{
    node->TC-=m_RaiseStep;
    if (node->TC<0) node->TC=0;
}

