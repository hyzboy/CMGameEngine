// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__FB21BBF8_08A9_4EE4_8258_94300AFC6372__INCLUDED_)
#define AFX_MAINFRM_H__FB21BBF8_08A9_4EE4_8258_94300AFC6372__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColourPopup.h"
#include "FinderView.h"

class CMainFrame : public CCJFrameWnd
{
    
protected: // create from serialization only
    CMainFrame();
    DECLARE_DYNCREATE(CMainFrame)
        
        // Attributes
public:
    
    // Operations
public:
    void EnableAdd();
    void DisableAdd();
    void Mcheck();
    
    // Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMainFrame)
public:
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    //}}AFX_VIRTUAL
    
    // Implementation
public:
    virtual ~CMainFrame();
    
    CDialogBar* GetDlgBar() { return &m_wndDlgBar;}
    
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif
    
    
protected:  // control bar embedded members
    CCJStatusBar    m_wndStatusBar;
    CCJToolBar      m_wndToolBar;
    CDialogBar      m_wndDlgBar;
    CColourPopup    m_wndColPopup;
	CCJWindowPlacement	m_state;
    
    // Generated message map functions
protected:
    //{{AFX_MSG(CMainFrame)
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnClose();
	afx_msg void OnUpdateViewGrid(CCmdUI* pCmdUI);
	afx_msg void OnViewGrid();
	afx_msg void OnHelp();
	//}}AFX_MSG
    afx_msg LONG OnSelTC(UINT lParam, LONG /*wParam*/);
    afx_msg void OnEditMapMode();
    afx_msg void OnRaiseMapMode();
    afx_msg void OnLowerMapMode();
    afx_msg void OnControlMapMode();
    afx_msg void OnAddWalker();
    afx_msg void OnRemoveWalker();
    afx_msg void OnPlay();
    afx_msg void OnStop();
    afx_msg void OnStep();
    afx_msg void OnParam();
    afx_msg void OnPenSizeX();
    afx_msg void OnPenSizeY();
    afx_msg void OnPenRaiseStep();
    afx_msg void OnSpeed();
    afx_msg void OnPriority();
    afx_msg void OnTimeStep();
    afx_msg void OnReset();
    
    afx_msg void OnUpdatePos(CCmdUI *pCmdUI);
    afx_msg void OnUpdateNode(CCmdUI *pCmdUI);
    afx_msg void OnUpdateMode(CCmdUI *pCmdUI);
    afx_msg void OnUpdateSel(CCmdUI *pCmdUI);

    
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__FB21BBF8_08A9_4EE4_8258_94300AFC6372__INCLUDED_)
