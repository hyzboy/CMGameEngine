#ifndef _CONST_H_
#define _CONST_H_

#define MIN_WND_SX 400
#define MIN_WND_SY 300
#define MIN_PEN_SIZE 1
#define MAX_PEN_SIZE 40
#define MIN_PEN_RAISE_STEP 1
#define MAX_PEN_RAISE_STEP 0xFF
#define MIN_WSPEED 1
#define MAX_WSPEED 20
#define MIN_WPRIORITY 1
#define MAX_WPRIORITY 100
#define MIN_TIMESTEP 1
#define MAX_TIMESTEP 100

#define RECTANGLE_COLOR DDRGB(0xFF, 0x00, 0x00)
#define GRID_COLOR DDRGB(0xA0, 0xA0, 0xA0)
#define BORDER_COLOR DDRGB(0x0, 0x0, 0x0)

#define SB_SIZE 8
#define TILE_X 16
#define TILE_Y 16

#define CONTROL_MAP     0
#define EDIT_MAP        1
#define LOWER_MAP       2
#define RAISE_MAP       3
#define EDIT_ADDWALKER  10

#define TID_REFRESH 101
#endif