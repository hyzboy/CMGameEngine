// FinderView.h : interface of the CFinderView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FINDERVIEW_H__170C7CEC_5556_4E8F_9E9B_0C7B7463B578__INCLUDED_)
#define AFX_FINDERVIEW_H__170C7CEC_5556_4E8F_9E9B_0C7B7463B578__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FinderDoc.h"
#include "const.h"
#include "pathlib.h"

class CFinderView : public CCDDrawView
{
protected: // create from serialization only
	CFinderView();
	DECLARE_DYNCREATE(CFinderView)

// Attributes
public:
	CFinderDoc* GetDocument();
  
  BOOL RecalculateScrolling(CRect* rect, BOOL ResetPos=FALSE);
  BOOL InitGraphics();
  BOOL InitWalkerSettings(Walker* w);
  
  void CopySelection(CRect* r);
  void ClearSelection(CRect* r);
  void DrawSelection(CRect* r);
  void UpdateSelection(CRect* r);

  void DrawSelectionGDI(CRect* r);
  void DrawSelectionDD(CRect* r);
  void ClearSelectionDD(CRect* r);
  
  void UpdateEnginePanel();
  void UpdateWalkerPanel();

  void Point2Tile(int px, int py, int *tx, int *ty);
  void Tile2Point(int tx, int ty, char type, int *px, int *py);
  void CenterTile2PenSquare(int tx, int ty, CRect &c);

  void RaiseTile(MapNode* node);
  void LowerTile(MapNode* node);


  LPDIRECTDRAWSURFACE    lpDDSG;       // Graphics surface

  int m_PosX, m_PosY;
  int m_TX, m_TY;

  CSize m_sizeDoc;
  CSize m_sizePage;
  CSize m_sizeLine;

  int m_Tile;
  int m_PenSizeX;
  int m_PenSizeY;
  int m_BkgndTile;
  int m_EditMode;
  int m_LastMode;
  int m_CenterTileX;
  int m_CenterTileY;
  int m_RaiseStep;
  int m_Priority;
  int m_Speed;
  int m_TimeStep;

  BOOL m_Running;
  BOOL m_SelectionOn;
  int m_Sel;

  BOOL    m_LButton;
  BOOL    m_RButton;
  BOOL    m_NeedRedraw;

  CRect m_Selection;
  CPoint m_ClickPoint;

  BOOL m_GridOn;

  CWnd* m_DlgBar;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFinderView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	virtual BOOL OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll = TRUE);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual BOOL OnScrollBy(CSize sizeScroll, BOOL bDoScroll = TRUE);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFinderView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFinderView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FinderView.cpp
inline CFinderDoc* CFinderView::GetDocument()
   { return (CFinderDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDERVIEW_H__170C7CEC_5556_4E8F_9E9B_0C7B7463B578__INCLUDED_)
