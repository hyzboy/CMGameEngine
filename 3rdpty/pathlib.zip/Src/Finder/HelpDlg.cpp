// HelpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Finder.h"
#include "HelpDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CHelpDlg dialog


CHelpDlg::CHelpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHelpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHelpDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CHelpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHelpDlg)
	DDX_Control(pDX, IDC_EXPLORER, m_Browser);
	//}}AFX_DATA_MAP
    COleVariant v2;
    
    CWinApp* app = AfxGetApp();
    CString s(app->m_pszHelpFilePath);
    
    while (s[s.GetLength()-1]!='\\') s.Delete(s.GetLength()-1,1);
    s+="Doc\\Finder\\index.html";

    m_Browser.Navigate(s, v2, v2, v2, v2);
    m_Browser.SetToolBar(1);
    m_Browser.SetAddressBar(1);

    SetWindowPos(&wndTop ,0, 0, 640, 400, SWP_NOMOVE);
    
}


BEGIN_MESSAGE_MAP(CHelpDlg, CDialog)
	//{{AFX_MSG_MAP(CHelpDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHelpDlg message handlers

void CHelpDlg::Help() 
{
    DoModal();
}

void CHelpDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
    if (m_Browser.m_hWnd) m_Browser.SetWindowPos(&wndTop, 0, 0, cx, cy, SWP_SHOWWINDOW);
}
