// NewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Finder.h"
#include "NewDlg.h"

#include "pathlib.h"

/*#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif*/

/////////////////////////////////////////////////////////////////////////////
// CNewDlg dialog

CNewDlg::CNewDlg(CWnd* pParent /*=NULL*/, char mode /*=0*/)
	: CDialog(CNewDlg::IDD, pParent)
{
  m_Mode = mode;
  //{{AFX_DATA_INIT(CNewDlg)
	m_HeapSize = 400;
	m_MPCPT = 1;
	m_MaxReq = 100;
	m_MSX = 50;
	m_MSY = 50;
	m_MaxWalkers = 50;
	m_MAXTC = PC_MAXTC;
	m_HC = PC_BASE_COST1;
	m_FSC = PC_STEP_COST;
	m_DC = PC_BASE_COST2;
	m_BFS = PC_BADSHIFT;
	m_BFR = PC_BADFINALRATIO;
	m_BC = PC_BASE_COST;
	m_ND = PC_NEAR_DESTINATION;
	m_SBC = PC_STANDING_BLOCKER_COST;
	m_WBC = PC_WALKING_BLOCKER_COST;
	m_WT = PC_WAITING_TIMEOUT;
	m_FSB = PC_FSBEHIND;
	m_HeurSel = 0;
	m_MixCoef = 0.5f;
	m_MixFuncSel = 1;
	m_DT = PC_DEADLOCK_TIMEOUT;
	//}}AFX_DATA_INIT
}

void CNewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CNewDlg)
	DDX_Control(pDX, IDC_MIXCOEF, m_MixCoefCtrl);
	DDX_Text(pDX, IDC_HEAPSIZE, m_HeapSize);
	DDV_MinMaxInt(pDX, m_HeapSize, 1, 1000000);
	DDX_Text(pDX, IDC_MPCPT, m_MPCPT);
	DDV_MinMaxInt(pDX, m_MPCPT, 1, 6000);
	DDX_Text(pDX, IDC_MREQUESTS, m_MaxReq);
	DDV_MinMaxInt(pDX, m_MaxReq, 1, 500);
	DDX_Text(pDX, IDC_MSX, m_MSX);
	DDV_MinMaxInt(pDX, m_MSX, 10, 10000);
	DDX_Text(pDX, IDC_MSY, m_MSY);
	DDV_MinMaxInt(pDX, m_MSY, 10, 10000);
	DDX_Text(pDX, IDC_MWALKERS, m_MaxWalkers);
	DDV_MinMaxInt(pDX, m_MaxWalkers, 1, 500);
	DDX_Text(pDX, IDC_MAXTC, m_MAXTC);
	DDV_MinMaxInt(pDX, m_MAXTC, 0, 50000);
	DDX_Text(pDX, IDC_HC, m_HC);
	DDV_MinMaxInt(pDX, m_HC, 0, 50000);
	DDX_Text(pDX, IDC_FSC, m_FSC);
	DDV_MinMaxInt(pDX, m_FSC, 0, 50000);
	DDX_Text(pDX, IDC_DC, m_DC);
	DDV_MinMaxInt(pDX, m_DC, 0, 50000);
	DDX_Text(pDX, IDC_BFS, m_BFS);
	DDV_MinMaxInt(pDX, m_BFS, -1000, 1000);
	DDX_Text(pDX, IDC_BFR, m_BFR);
	DDV_MinMaxInt(pDX, m_BFR, 0, 1000);
	DDX_Text(pDX, IDC_BC, m_BC);
	DDV_MinMaxInt(pDX, m_BC, 0, 50000);
	DDX_Text(pDX, IDC_ND, m_ND);
	DDV_MinMaxInt(pDX, m_ND, 0, 1000000);
	DDX_Text(pDX, IDC_SBC, m_SBC);
	DDV_MinMaxInt(pDX, m_SBC, 0, 50000);
	DDX_Text(pDX, IDC_WBC, m_WBC);
	DDV_MinMaxInt(pDX, m_WBC, 0, 50000);
	DDX_Text(pDX, IDC_WT, m_WT);
	DDV_MinMaxInt(pDX, m_WT, 0, 1000);
	DDX_Text(pDX, IDC_FSB, m_FSB);
	DDV_MinMaxInt(pDX, m_FSB, 0, 10000);
	DDX_CBIndex(pDX, IDC_HEUR, m_HeurSel);
	DDX_Text(pDX, IDC_MIXCOEF, m_MixCoef);
	DDV_MinMaxFloat(pDX, m_MixCoef, 0.f, 1.f);
	DDX_CBIndex(pDX, IDC_MIXFUNC, m_MixFuncSel);
	DDX_Text(pDX, IDC_DT, m_DT);
	DDV_MinMaxInt(pDX, m_DT, 0, 1000);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNewDlg, CDialog)
	//{{AFX_MSG_MAP(CNewDlg)
	ON_CBN_SELCHANGE(IDC_MIXFUNC, OnSelchangeMixfunc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewDlg message handlers

BOOL CNewDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  if (m_Mode==1)
  {
    GetDlgItem(IDC_GMAP)->EnableWindow(FALSE);
    GetDlgItem(IDC_MSX)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMSX)->EnableWindow(FALSE);
    GetDlgItem(IDC_MSY)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMSY)->EnableWindow(FALSE);

    GetDlgItem(IDC_GMEMORY)->EnableWindow(FALSE);
    GetDlgItem(IDC_HEAPSIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_SHEAPSIZE)->EnableWindow(FALSE);
    GetDlgItem(IDC_MWALKERS)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMWALKERS)->EnableWindow(FALSE);
    GetDlgItem(IDC_MPCPT)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMPCPT)->EnableWindow(FALSE);
    GetDlgItem(IDC_MREQUESTS)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMREQUESTS)->EnableWindow(FALSE);
  }

  OnSelchangeMixfunc();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewDlg::OnSelchangeMixfunc() 
{
  UpdateData(TRUE);
  if (m_MixFuncSel)
  {
    GetDlgItem(IDC_MIXCOEF)->EnableWindow(FALSE);
    GetDlgItem(IDC_SMIXCOEF)->EnableWindow(FALSE);
  }
  else
  {
    GetDlgItem(IDC_MIXCOEF)->EnableWindow(TRUE);
    GetDlgItem(IDC_SMIXCOEF)->EnableWindow(TRUE);
  }
}
