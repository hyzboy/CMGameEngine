// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Finder.h"

#include "MainFrm.h"
#include "FinderDoc.h"
#include "FinderView.h"
#include "ColourPopup.h"
#include "NewDlg.h"
#include "HelpDlg.h"
#include "const.h"

#include "PathLib.h"

/*#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif*/

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
//{{AFX_MSG_MAP(CMainFrame)
ON_WM_CREATE()
ON_WM_SIZING()
ON_WM_CLOSE()
	ON_COMMAND(ID_HELP, OnHelp)
	//}}AFX_MSG_MAP
ON_MESSAGE(CPN_SELTC,           OnSelTC)
ON_COMMAND(ID_VIEWGRID,         OnViewGrid)
ON_COMMAND(IDC_EDRESET,         OnReset)
ON_COMMAND(IDC_WADD,            OnAddWalker)
ON_COMMAND(IDC_WREMOVE,         OnRemoveWalker)
ON_COMMAND(ID_CPLAY,            OnPlay)
ON_COMMAND(ID_CSTOP,            OnStop)
ON_COMMAND(ID_CSTEP,            OnStep)
ON_COMMAND(ID_PARAM,            OnParam)
ON_COMMAND(ID_EDITMAP,          OnEditMapMode)
ON_COMMAND(ID_RAISEMAP,         OnRaiseMapMode)
ON_COMMAND(ID_LOWERMAP,         OnLowerMapMode)
ON_COMMAND(ID_CONTROLMAP,       OnControlMapMode)
ON_CONTROL(EN_KILLFOCUS, IDC_PENSEDITX, OnPenSizeX)
ON_CONTROL(EN_KILLFOCUS, IDC_PENSEDITY, OnPenSizeY)
ON_CONTROL(EN_KILLFOCUS, IDC_RSEDIT, OnPenRaiseStep)
ON_CONTROL(EN_KILLFOCUS, IDC_WSPEED, OnSpeed)
ON_CONTROL(EN_KILLFOCUS, IDC_WPRIORITY, OnPriority)
ON_CONTROL(EN_KILLFOCUS, IDC_TIMEEDIT, OnTimeStep)
ON_UPDATE_COMMAND_UI(ID_WV_POS, OnUpdatePos)
ON_UPDATE_COMMAND_UI(ID_WV_NODE, OnUpdateNode)
ON_UPDATE_COMMAND_UI(ID_WV_MODE, OnUpdateMode)
ON_UPDATE_COMMAND_UI(ID_WV_SEL, OnUpdateSel)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	    ID_SEPARATOR,           // status line indicator
	    ID_WV_MODE,
	    ID_WV_SEL,
	    ID_WV_NODE,
	    ID_WV_POS,
		ID_INDICATOR_CAPS,
		ID_INDICATOR_NUM,
		ID_INDICATOR_SCRL,
};

void CMainFrame::EnableAdd()
{
	m_wndDlgBar.GetDlgItem(IDC_SSPEED)->EnableWindow(TRUE);
	m_wndDlgBar.GetDlgItem(IDC_WSPEED)->EnableWindow(TRUE);
	m_wndDlgBar.GetDlgItem(IDC_SPRIORITY)->EnableWindow(TRUE);
	m_wndDlgBar.GetDlgItem(IDC_WPRIORITY)->EnableWindow(TRUE);
}

void CMainFrame::DisableAdd()
{
	m_wndDlgBar.GetDlgItem(IDC_SSPEED)->EnableWindow(FALSE);
	m_wndDlgBar.GetDlgItem(IDC_WSPEED)->EnableWindow(FALSE);
	m_wndDlgBar.GetDlgItem(IDC_SPRIORITY)->EnableWindow(FALSE);
	m_wndDlgBar.GetDlgItem(IDC_WPRIORITY)->EnableWindow(FALSE);
}

void CMainFrame::Mcheck()
{
	CFinderView* view = (CFinderView*)GetActiveView();
    switch (view->m_EditMode) {
    case EDIT_MAP:
        m_wndToolBar.GetToolBarCtrl().CheckButton(9);
        break;
    case LOWER_MAP:
        m_wndToolBar.GetToolBarCtrl().CheckButton(10);
        break;
    case RAISE_MAP:
        m_wndToolBar.GetToolBarCtrl().CheckButton(11);
        break;
    case CONTROL_MAP:
        m_wndToolBar.GetToolBarCtrl().CheckButton(12);
        break;
    }

}


/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	
}

CMainFrame::~CMainFrame()
{
	
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

/*    if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}*/

    if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0,0,0,0)) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	
	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);
	DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP);

    if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	
	if (!m_wndDlgBar.Create(this, IDD_MAINBAR,
		CBRS_RIGHT|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_MAINBAR))
	{
		TRACE0("Failed to create DlgBar\n");
		return -1;      // fail to create
	}
	CWnd *Edit  =  m_wndDlgBar.GetDlgItem(IDC_WSPEED);
	if (Edit)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_WSPEED, MIN_WSPEED);
	}
	
	Edit  =  m_wndDlgBar.GetDlgItem(IDC_WPRIORITY);
	if (Edit)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_WPRIORITY, MIN_WPRIORITY);
	}
	
	CWnd *PENSEDITX =  m_wndDlgBar.GetDlgItem(IDC_PENSEDITX);
	CWnd *PENSEDITY =  m_wndDlgBar.GetDlgItem(IDC_PENSEDITY);
	CWnd *rsEdit  =  m_wndDlgBar.GetDlgItem(IDC_RSEDIT);
	CSpinButtonCtrl *rsSpin = (CSpinButtonCtrl *) m_wndDlgBar.GetDlgItem(IDC_RSSPIN);
	CSpinButtonCtrl *psSpinX = (CSpinButtonCtrl *) m_wndDlgBar.GetDlgItem(IDC_PSSPINX);
	CSpinButtonCtrl *psSpinY = (CSpinButtonCtrl *) m_wndDlgBar.GetDlgItem(IDC_PSSPINY);
	CSpinButtonCtrl *TimeSpin = (CSpinButtonCtrl *) m_wndDlgBar.GetDlgItem(IDC_TIMESPIN);
	
	Edit  =  m_wndDlgBar.GetDlgItem(IDC_TIMEEDIT);
	if (Edit)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_TIMEEDIT, MIN_TIMESTEP);
	}
	
	if (TimeSpin)
	{
		TimeSpin->SetBuddy(Edit);
		TimeSpin->SetRange(MIN_TIMESTEP, MAX_TIMESTEP);
	}
	
	if (rsEdit)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_RSEDIT, 10);
	}
	
	if (PENSEDITX)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_PENSEDITX, 1);
	}
	
	if (PENSEDITY)
	{
		m_wndDlgBar.SetDlgItemInt(IDC_PENSEDITY, 1);
	}
	
	
	if (rsSpin)
	{
		rsSpin->SetBuddy(rsEdit);
		rsSpin->SetRange(MIN_PEN_RAISE_STEP, MAX_PEN_RAISE_STEP);
	}
	
	if (psSpinX)
	{
		psSpinX->SetBuddy(PENSEDITX);
		psSpinX->SetRange(MIN_PEN_SIZE, MAX_PEN_SIZE);
	}
	
	if (psSpinY)
	{
		psSpinY->SetBuddy(PENSEDITY);
		psSpinY->SetRange(MIN_PEN_SIZE, MAX_PEN_SIZE);
	}
	
	CRect pos;
	m_wndDlgBar.GetDlgItem(IDC_MAPEDIT)->GetWindowRect(&pos);
	m_wndDlgBar.ScreenToClient(&pos);
	if (!m_wndColPopup.Create(CPoint(pos.left+5, pos.top+13),    // Point to display popup
		RGB(255,255,255),        // Selected colour
		&m_wndDlgBar,           // parent
		this,                   // send messages directly to me
		NULL,                   // "Default" text area
		NULL))                  // Custom Text
	{
		TRACE0("Failed to create CoulorPopup\n");
		return -1;      // fail to create
	}
	m_wndDlgBar.CheckDlgButton(ID_VIEWGRID,1);
	
	m_wndToolBar.SetButtonStyle(5, TBSTYLE_BUTTON);
	m_wndToolBar.SetButtonStyle(6, TBSTYLE_CHECK|TBBS_GROUP);
	m_wndToolBar.SetButtonStyle(7, TBSTYLE_CHECK|TBBS_GROUP);
	
    m_wndToolBar.SetButtonStyle(9, TBSTYLE_CHECK|TBBS_GROUP);
	m_wndToolBar.SetButtonStyle(10, TBSTYLE_CHECK|TBBS_GROUP);
	m_wndToolBar.SetButtonStyle(11, TBSTYLE_CHECK|TBBS_GROUP);
	m_wndToolBar.SetButtonStyle(12, TBSTYLE_CHECK|TBBS_GROUP);
	
    m_wndToolBar.GetToolBarCtrl().CheckButton(12);
    m_wndToolBar.GetToolBarCtrl().CheckButton(7);

    DisableAdd();
//    ((CButton*)GetDlgItem(ID_CSTOP))->SetCheck(1);

    // Restore the previous bar and window states.
//	LoadBarState(_T("Bar State"));
//	m_state.LoadWindowPos(this);

    return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CCJFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

LONG CMainFrame::OnSelTC(UINT lParam, LONG /*wParam*/)
{
	
	COLORREF crNewColour = (COLORREF) lParam;
	int H = 0xFF-(crNewColour&0xFF);
	if (H!=0xFF)
		((CFinderView*)GetActiveView())->m_Tile = H;
	else
		((CFinderView*)GetActiveView())->m_Tile = PC_MAXTC;
	
	return TRUE;
}

void CMainFrame::OnAddWalker() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
    m_wndToolBar.GetToolBarCtrl().CheckButton(9, FALSE);
    m_wndToolBar.GetToolBarCtrl().CheckButton(10, FALSE);
    m_wndToolBar.GetToolBarCtrl().CheckButton(11, FALSE);
    m_wndToolBar.GetToolBarCtrl().CheckButton(12, FALSE);
	view->m_LastMode = view->m_EditMode;
	view->m_EditMode = EDIT_ADDWALKER;
	EnableAdd();
}

void CMainFrame::OnRemoveWalker() 
{
	CFinderDoc* pDoc = (CFinderDoc*)GetActiveDocument();
	ASSERT_VALID(pDoc);
	
	PED* PE = pDoc->Engine;
	ASSERT(PE);
	
	Walker* w = PE->FirstWalker;
	while (w)
	{
		if (w->State&PEW_SELECTED)  // if walker is selected
			peRemoveWalker(PE, w);    // remove him
		w = w->Next;
	}
	CFinderView* view = (CFinderView*)GetActiveView();
	view->m_NeedRedraw = TRUE;
}

void CMainFrame::OnPlay() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	CToolBarCtrl *tb = &m_wndToolBar.GetToolBarCtrl();
    m_wndToolBar.GetToolBarCtrl().CheckButton(5);
	view->m_Running = TRUE;
}

void CMainFrame::OnStop() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
    m_wndToolBar.GetToolBarCtrl().CheckButton(6);
	view->m_Running = FALSE;
}

void CMainFrame::OnStep() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	view->m_Running = FALSE;
	peTimeForward(view->GetDocument()->Engine, view->m_TimeStep);
	view->m_NeedRedraw = TRUE;
    m_wndToolBar.GetToolBarCtrl().CheckButton(7);
}

void CMainFrame::OnParam() 
{
  CNewDlg NewDlg(NULL, 1);
  CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
  PED *PE = view->GetDocument()->Engine;
  
  view->m_Running = FALSE;
  
  NewDlg.m_MAXTC = PE->MAXTC;
  NewDlg.m_SBC = PE->StandingBlockerCost;
  NewDlg.m_WBC = PE->WalkingBlockerCost;
  NewDlg.m_FSC = PE->FootStepCost;
  NewDlg.m_BC = PE->BaseCost; 
  NewDlg.m_HC = PE->HorizontalCost; 
  NewDlg.m_DC = PE->DiagonalCost;
  NewDlg.m_ND = PE->NearDestination;
  NewDlg.m_BFR = PE->BadFinalRatio;
  NewDlg.m_BFS = PE->BadFinalShift;
  NewDlg.m_WT = PE->WaitingTimeout;
  NewDlg.m_DT = PE->DeadlockTimeout;
  NewDlg.m_FSB = PE->FSBehind;
  
  if (PE->Heuristics==HeuristicsMax) NewDlg.m_HeurSel=0;
  if (PE->Heuristics==HeuristicsManhattan) NewDlg.m_HeurSel=1;
  if (PE->Heuristics==HeuristicsEuclidean) NewDlg.m_HeurSel=2;
  
  if (PE->MixFunction==MixCustom) NewDlg.m_MixFuncSel=0;
  NewDlg.m_MixCoef = PE->MixCoef;
  if (PE->MixFunction==MixAStar) NewDlg.m_MixFuncSel=1;
  if (PE->MixFunction==MixDijkstra) NewDlg.m_MixFuncSel=2;
  if (PE->MixFunction==MixBestFirst) NewDlg.m_MixFuncSel=3;
  
  if (NewDlg.DoModal()!=IDOK) return;
  peSetSettings(PE, NewDlg.m_MAXTC, NewDlg.m_SBC, NewDlg.m_WBC, NewDlg.m_FSC, 
    NewDlg.m_BC, NewDlg.m_HC, NewDlg.m_DC, NewDlg.m_ND, NewDlg.m_BFR, NewDlg.m_BFS, 
    NewDlg.m_FSB, NewDlg.m_WT, NewDlg.m_DT);
  switch (NewDlg.m_HeurSel) {
  case 0: peSetHeuristics(PE, HeuristicsMax); break;
  case 1: peSetHeuristics(PE, HeuristicsManhattan); break;
  case 2: peSetHeuristics(PE, HeuristicsEuclidean); break;
  }
  switch (NewDlg.m_MixFuncSel) {
  case 0: peSetMixFunction(PE, MixCustom); peSetMixCoef(PE, NewDlg.m_MixCoef); break;
  case 1: peSetMixFunction(PE, MixAStar); break;
  case 2: peSetMixFunction(PE, MixDijkstra); break;
  case 3: peSetMixFunction(PE, MixBestFirst); break;
  }
}

void CMainFrame::OnEditMapMode() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	if (view->m_EditMode != EDIT_MAP)
	{  
		view->m_EditMode = EDIT_MAP;
		view->m_NeedRedraw = TRUE;
		DisableAdd();
	}
}

void CMainFrame::OnControlMapMode() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	if (view->m_EditMode != CONTROL_MAP)
	{  
		view->m_EditMode = CONTROL_MAP;
		view->m_NeedRedraw = TRUE;
		DisableAdd();
	}
}

void CMainFrame::OnRaiseMapMode() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	if (view->m_EditMode != RAISE_MAP)
	{  
		view->m_EditMode = RAISE_MAP;
		view->m_NeedRedraw = TRUE;
		DisableAdd();
	}
}

void CMainFrame::OnLowerMapMode() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	if (view->m_EditMode != LOWER_MAP)
	{  
		view->m_EditMode = LOWER_MAP;
		view->m_NeedRedraw = TRUE;
		DisableAdd();
	}
}

void CMainFrame::OnSizing(UINT fwSide, LPRECT pRect) 
{
	CRect r(pRect);
	
	if (r.Width()<MIN_WND_SX)
	{
		switch (fwSide)
		{
		case WMSZ_BOTTOMLEFT:
		case WMSZ_LEFT:
		case WMSZ_TOPLEFT:
			r.left-=MIN_WND_SX-r.Width();
			break;
			
		case WMSZ_BOTTOMRIGHT:
		case WMSZ_RIGHT:
		case WMSZ_TOPRIGHT:
			r.right+=MIN_WND_SX-r.Width();
			break;
		}
	}
	if (r.Height()<MIN_WND_SY)
	{
		switch (fwSide)
		{
		case WMSZ_TOPLEFT:
		case WMSZ_TOP:
		case WMSZ_TOPRIGHT:
			r.top-=MIN_WND_SY-r.Height();
			break;
			
		case WMSZ_BOTTOMLEFT:
		case WMSZ_BOTTOM:
		case WMSZ_BOTTOMRIGHT:
			r.bottom+=MIN_WND_SY-r.Height();
			break;
		}
	}
	
	pRect->left = r.left;
	pRect->right = r.right;
	pRect->top = r.top;
	pRect->bottom = r.bottom;
	
	CCJFrameWnd::OnSizing(fwSide, pRect);
}

void CMainFrame::OnPenSizeX() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i= m_wndDlgBar.GetDlgItemInt(IDC_PENSEDITX, &res);
	if (res && view)
	{
		if (i<MIN_PEN_SIZE) i=MIN_PEN_SIZE;
		if (i>MAX_PEN_SIZE) i=MAX_PEN_SIZE;
		m_wndDlgBar.SetDlgItemInt(IDC_PENSEDITX, i);
		view->m_PenSizeX = i;
	}
}

void CMainFrame::OnPenSizeY() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i= m_wndDlgBar.GetDlgItemInt(IDC_PENSEDITY, &res);
	if (res && view)
	{
		if (i<MIN_PEN_SIZE) i=MIN_PEN_SIZE;
		if (i>MAX_PEN_SIZE) i=MAX_PEN_SIZE;
		m_wndDlgBar.SetDlgItemInt(IDC_PENSEDITY, i);
		view->m_PenSizeY = i;
	}
}

void CMainFrame::OnPenRaiseStep() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i= m_wndDlgBar.GetDlgItemInt(IDC_RSEDIT, &res);
	if (res && view)
	{
		if (i<MIN_PEN_RAISE_STEP) i=MIN_PEN_RAISE_STEP;
		if (i>MAX_PEN_RAISE_STEP) i=MAX_PEN_RAISE_STEP;
		m_wndDlgBar.SetDlgItemInt(IDC_RSEDIT, i);
		view->m_RaiseStep = i;
	}
}

void CMainFrame::OnSpeed() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i= m_wndDlgBar.GetDlgItemInt(IDC_WSPEED, &res);
	if (res && view)
	{
		if (i<MIN_WSPEED) i=MIN_WSPEED;
		if (i>MAX_WSPEED) i=MAX_WSPEED;
		m_wndDlgBar.SetDlgItemInt(IDC_WSPEED, i);
		view->m_Speed = i;
	}
}

void CMainFrame::OnPriority() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i= m_wndDlgBar.GetDlgItemInt(IDC_WPRIORITY, &res);
	if (res && view)
	{
		if (i<MIN_WPRIORITY) i=MIN_WPRIORITY;
		if (i>MAX_WPRIORITY) i=MAX_WPRIORITY;
		m_wndDlgBar.SetDlgItemInt(IDC_WPRIORITY, i);
		view->m_Priority = i;
	}
}

void CMainFrame::OnTimeStep() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	BOOL res;
	
	int i = m_wndDlgBar.GetDlgItemInt(IDC_TIMEEDIT, &res);
	if (res && view)
	{
		if (i<MIN_TIMESTEP) i=MIN_TIMESTEP;
		if (i>MAX_TIMESTEP) i=MAX_TIMESTEP;
		m_wndDlgBar.SetDlgItemInt(IDC_TIMEEDIT, i);
		view->m_TimeStep = i;
	}
}

void CMainFrame::OnReset() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	PED *PE = view->GetDocument()->Engine;

  peENodes = 0;
	view->m_NeedRedraw = TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG


void CMainFrame::OnClose() 
{
	// Save the bar and window states.
	m_state.SaveWindowPos(this);
	SaveBarState(_T("Bar State"));
	
	CCJFrameWnd::OnClose();
}

void CMainFrame::OnUpdateViewGrid(CCmdUI* pCmdUI) 
{
    OnViewGrid();
}

void CMainFrame::OnViewGrid() 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
	view->m_GridOn = m_wndDlgBar.IsDlgButtonChecked(ID_VIEWGRID);
	view->m_NeedRedraw = TRUE;
}

void CMainFrame::OnHelp() 
{
    CHelpDlg dlg;

    dlg.Help();
}

void CMainFrame::OnUpdatePos(CCmdUI *pCmdUI) 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
    pCmdUI->Enable(); 
    CString strPage;
    strPage.Format( "Pos [%d,%d]", view->m_PosX, view->m_PosY); 
    pCmdUI->SetText( strPage ); 
}

void CMainFrame::OnUpdateNode(CCmdUI *pCmdUI) 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
    pCmdUI->Enable(); 
    CString strPage;
    strPage.Format( "Node [%d,%d]", view->m_TX, view->m_TY); 
    pCmdUI->SetText( strPage ); 
}

void CMainFrame::OnUpdateSel(CCmdUI *pCmdUI) 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
    pCmdUI->Enable(); 
    CString strPage;
    strPage.Format( "Sel [%d]", view->m_Sel); 
    pCmdUI->SetText( strPage ); 
}

void CMainFrame::OnUpdateMode(CCmdUI *pCmdUI) 
{
	CFinderView* view = (CFinderView*)GetActiveView();
  if (!view) return;
    pCmdUI->Enable(); 
    CString strPage;
    switch (view->m_EditMode) {
    case EDIT_MAP:
        strPage.Format("Mode: Edit map"); 
        break;
    case LOWER_MAP:
        strPage.Format("Mode: Lower map"); 
        break;
    case RAISE_MAP:
        strPage.Format("Mode: Raise map"); 
        break;
    case CONTROL_MAP:
        strPage.Format("Mode: Control walkers"); 
        break;
    case EDIT_ADDWALKER:
        strPage.Format("Mode: Add walkers"); 
        break;
    }
    pCmdUI->SetText( strPage ); 
}


