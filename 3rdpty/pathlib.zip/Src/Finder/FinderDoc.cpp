// FinderDoc.cpp : implementation of the CFinderDoc class
//

#include "stdafx.h"

#include "MainFrm.h"
#include "Finder.h"
#include "FinderDoc.h"
#include "NewDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFinderDoc

IMPLEMENT_DYNCREATE(CFinderDoc, CDocument)

BEGIN_MESSAGE_MAP(CFinderDoc, CDocument)
//{{AFX_MSG_MAP(CFinderDoc)
// NOTE - the ClassWizard will add and remove mapping macros here.
//    DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinderDoc construction/destruction

CFinderDoc::CFinderDoc()
{
    // TODO: add one-time construction code here
    DocReady = FALSE;
    Engine = NULL;
}

CFinderDoc::~CFinderDoc()
{
}

void CFinderDoc::DeleteContents()
{
    // Re-initialize document data here.
    if (DocReady)
    {
        DocReady = FALSE;
        POSITION pos = GetFirstViewPosition();
        while (pos != NULL)
        {
            CView* pView = GetNextView(pos);
            pView->KillTimer(TID_REFRESH);
        }   
        if (Engine)
            peDone(Engine);
        
    }
}


BOOL CFinderDoc::OnNewDocument()
{
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    CFinderView* view = (CFinderView*)frame->GetActiveView();
    if (view) view->m_Running = FALSE;
    
    CNewDlg NewDlg(NULL, 0);
    if (NewDlg.DoModal()!=IDOK) return FALSE;
    
    DeleteContents();
    Engine = peInit(NewDlg.m_MSX, NewDlg.m_MSY, NewDlg.m_MaxReq, 
        NewDlg.m_HeapSize, NewDlg.m_MPCPT, NewDlg.m_MaxWalkers);
    peSetSettings(Engine, NewDlg.m_MAXTC, NewDlg.m_SBC, NewDlg.m_WBC, NewDlg.m_FSC, 
        NewDlg.m_BC, NewDlg.m_HC, NewDlg.m_DC, NewDlg.m_ND, NewDlg.m_BFR, NewDlg.m_BFS, NewDlg.m_FSB, NewDlg.m_WT, NewDlg.m_DT);
    switch (NewDlg.m_HeurSel) {
    case 0: peSetHeuristics(Engine, HeuristicsMax); break;
    case 1: peSetHeuristics(Engine, HeuristicsManhattan); break;
    case 2: peSetHeuristics(Engine, HeuristicsEuclidean); break;
    }
    switch (NewDlg.m_MixFuncSel) {
    case 0: peSetMixFunction(Engine, MixCustom); peSetMixCoef(Engine, NewDlg.m_MixCoef); break;
    case 1: peSetMixFunction(Engine, MixAStar); break;
    case 2: peSetMixFunction(Engine, MixDijkstra); break;
    case 3: peSetMixFunction(Engine, MixBestFirst); break;
    }

    
    if (!Engine) 
    {  
        AfxMessageBox(IDS_ENGINEINITERROR, MB_OK|MB_ICONSTOP); 
        
        DocReady = FALSE;
        return FALSE;
    }
    
    SetModifiedFlag(TRUE);
    SetPathName("Untitled", FALSE);
    SetTitle("Untitled");
    

    DocReady = TRUE;
    
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFinderDoc diagnostics

#ifdef _DEBUG
void CFinderDoc::AssertValid() const
{
    CDocument::AssertValid();
}

void CFinderDoc::Dump(CDumpContext& dc) const
{
    CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFinderDoc commands

BOOL CFinderDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
    FILE* f;
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    CFinderView* view = (CFinderView*)frame->GetActiveView();
    if (view)
        view->m_Running = FALSE;

    peHeuristics* sHeuristics = Engine->Heuristics; 
    float sMixCoef = Engine->MixCoef;
    peMixFunction* sMixFunction = Engine->MixFunction;

    f = fopen(lpszPathName, "rb");
    if (!f) return FALSE;
    PED* NewEngine = peLoad(f);
    fclose(f);
    
    if (!NewEngine) 
    {  
        if (peLastError==PE_CORRUPTED)
          AfxMessageBox(IDS_ENGINECORRUPTED, MB_OK|MB_ICONEXCLAMATION);
        if (peLastError==PE_IOFAILED)
          AfxMessageBox(IDS_ENGINELOADERROR, MB_OK|MB_ICONEXCLAMATION);
        return FALSE;
    }
    
    DeleteContents();

    Engine = NewEngine;
    peSetMixCoef(Engine, sMixCoef);
    peSetHeuristics(Engine, sHeuristics);
    peSetMixFunction(Engine, sMixFunction);
    SetModifiedFlag(TRUE);
    DocReady = TRUE;
    
    view->UpdateEnginePanel();
    view->UpdateWalkerPanel();

    peENodes = 0;

    return TRUE;
}

BOOL CFinderDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
    FILE* f;
    char res;
    
    CMainFrame* frame = (CMainFrame*)AfxGetMainWnd();
    ASSERT_VALID(frame);
    CFinderView* view = (CFinderView*)frame->GetActiveView();
    if (view)
        view->m_Running = FALSE;
    
    f = fopen(lpszPathName, "wb");
    if (!f) return FALSE;
    res = peSave(Engine, f);
    fclose(f);
    
    SetModifiedFlag(TRUE);
    
    if (!res) AfxMessageBox(IDS_ENGINESAVEERROR, MB_OK|MB_ICONEXCLAMATION); 
    return res;
} 
