// FinderDoc.h : interface of the CFinderDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FINDERDOC_H__794CC5DF_F35C_4ABA_87F7_F2CA4068FCDE__INCLUDED_)
#define AFX_FINDERDOC_H__794CC5DF_F35C_4ABA_87F7_F2CA4068FCDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "const.h"
#include "pathlib.h"


class CFinderDoc : public CDocument
{
protected: // create from serialization only
	CFinderDoc();
	DECLARE_DYNCREATE(CFinderDoc)

// Attributes
public:
  BOOL DocReady;
  PED* Engine;

// Operations
public:
	CSize GetDocSize() const { return CSize(Engine->MapSX*TILE_X, Engine->MapSY*TILE_Y);}
  BOOL IsReady() { return DocReady;};
  virtual void DeleteContents();
  

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFinderDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFinderDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFinderDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDERDOC_H__794CC5DF_F35C_4ABA_87F7_F2CA4068FCDE__INCLUDED_)
