// stdafx.cpp : source file that includes just the standard includes
//	CJLibrary.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
//
// Copyright � 1999 CodeJock.com and 
// Copyright � 1998-1999 Kirk W. Stowell, All Rights Reserved.
//
// mailto:kstowell@codejock.com
// http://www.codejock.com
//
// Not to be used or distributed without proper registration.
//
/////////////////////////////////////////////////////////////////////////////
/****************************************************************************
 *
 * $Date: 8/31/99 1:11a $
 * $Revision: 4 $
 * $Archive: /CodeJockey/CJLibrary/StdAfx.cpp $
 *
 * $History: StdAfx.cpp $
 * 
 * *****************  Version 4  *****************
 * User: Kirk Stowell Date: 8/31/99    Time: 1:11a
 * Updated in $/CodeJockey/CJLibrary
 * Updated copyright and contact information.
 * 
 * *****************  Version 3  *****************
 * User: Kirk Stowell Date: 7/25/99    Time: 10:00p
 * Updated in $/CodeJockey/CJLibrary
 * 
 * *****************  Version 2  *****************
 * User: Kirk Stowell Date: 7/25/99    Time: 12:15a
 * Updated in $/CodeJockey/CJLibrary
 * 
 * *****************  Version 1  *****************
 * User: Kirk Stowell Date: 6/23/99    Time: 12:05a
 * Created in $/CodeJockey/CJLibrary
 *
 ***************************************************************************/
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
