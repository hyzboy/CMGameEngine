#!/bin/bash

cmake -G "Xcode" ..


